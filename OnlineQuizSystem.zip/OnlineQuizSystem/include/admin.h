#ifndef ADMIN_H
#define ADMIN_H

void adminPanel();

#endif

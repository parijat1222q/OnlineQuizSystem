#ifndef LEADERBOARD_H
#define LEADERBOARD_H

void viewLeaderboard();

#endif

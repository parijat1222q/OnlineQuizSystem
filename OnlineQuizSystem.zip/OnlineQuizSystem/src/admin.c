#include <stdio.h>
#include <string.h>
#include "admin.h"
#include "quiz.h"

int adminLogin() 
{
    char username[50], password[50];
    printf("Enter Admin Username: ");
    scanf("%s", username);
    printf("Enter Admin Password: ");
    scanf("%s", password);

    if (strcmp(username, "admin") == 0 && strcmp(password, "admin123") == 0) 
    {
        return 1;
    } 
    else 
    {
        printf("Invalid admin credentials!\n");
        return 0;
    }
}

void addQuestion() 
{
    FILE *file = fopen("data/questions.dat", "ab");
    Question q;
    getchar(); 
    printf("Enter the question: ");
    fgets(q.question, 256, stdin);
    printf("Enter option A: ");
    fgets(q.options[0], 100, stdin);
    printf("Enter option B: ");
    fgets(q.options[1], 100, stdin);
    printf("Enter option C: ");
    fgets(q.options[2], 100, stdin);
    printf("Enter option D: ");
    fgets(q.options[3], 100, stdin);
    printf("Enter the correct option (A/B/C/D): ");
    scanf(" %c", &q.correctOption);

    fwrite(&q, sizeof(Question), 1, file);
    fclose(file);
    printf("Question added successfully!\n");
}

void viewAllQuestions() 
{
    FILE *file = fopen("data/questions.dat", "rb");
    Question q;
    int questionNo = 1;

    while (fread(&q, sizeof(Question), 1, file)) 
    {
        printf("\nQuestion %d:\n", questionNo);
        printf("%s", q.question);
        printf("A) %s", q.options[0]);
        printf("B) %s", q.options[1]);
        printf("C) %s", q.options[2]);
        printf("D) %s", q.options[3]);
        printf("Correct Option: %c\n", q.correctOption);
        questionNo++;
    }

    fclose(file);
}

void editQuestion() 
{
    viewAllQuestions();

    FILE *file = fopen("data/questions.dat", "rb+");
    Question q;
    int questionNo, count = 1;

    printf("Enter the question number you want to edit: ");
    scanf("%d", &questionNo);

    while (fread(&q, sizeof(Question), 1, file)) 
    {
        if (count == questionNo) 
        {
            printf("Editing Question %d:\n", count);
            getchar(); 
            printf("Enter the new question: ");
            fgets(q.question, 256, stdin);
            printf("Enter new option A: ");
            fgets(q.options[0], 100, stdin);
            printf("Enter new option B: ");
            fgets(q.options[1], 100, stdin);
            printf("Enter new option C: ");
            fgets(q.options[2], 100, stdin);
            printf("Enter new option D: ");
            fgets(q.options[3], 100, stdin);
            printf("Enter new correct option (A/B/C/D): ");
            scanf(" %c", &q.correctOption);

            fseek(file, -sizeof(Question), SEEK_CUR);
            fwrite(&q, sizeof(Question), 1, file);
            printf("Question updated successfully!\n");
            break;
        }
        count++;
    }

    fclose(file);
}

void deleteQuestion() 
{
    viewAllQuestions();

    FILE *file = fopen("data/questions.dat", "rb");
    FILE *tempFile = fopen("data/temp.dat", "wb");
    Question q;
    int questionNo, count = 1;

    printf("Enter the question number you want to delete: ");
    scanf("%d", &questionNo);

    while (fread(&q, sizeof(Question), 1, file)) 
    {
        if (count != questionNo) 
        {
            fwrite(&q, sizeof(Question), 1, tempFile);
        }
        count++;
    }

    fclose(file);
    fclose(tempFile);

    remove("data/questions.dat");
    rename("data/temp.dat", "data/questions.dat");

    printf("Question deleted successfully!\n");
}

void adminPanel() 
{
    int choice;

    if (adminLogin()) 
    {
        do 
        {
            printf("\n--- Admin Panel ---\n");
            printf("1. Add Question\n");
            printf("2. View All Questions\n");
            printf("3. Edit Question\n");
            printf("4. Delete Question\n");
            printf("5. Logout\n");
            printf("Enter your choice: ");
            scanf("%d", &choice);

            switch (choice) 
            {
                case 1:
                    addQuestion();
                    break;
                case 2:
                    viewAllQuestions();
                    break;
                case 3:
                    editQuestion();
                    break;
                case 4:
                    deleteQuestion();
                    break;
                case 5:
                    printf("Logging out...\n");
                    break;
                default:
                    printf("Invalid choice!\n");
            }
        } 
        while (choice != 5);
    }
}

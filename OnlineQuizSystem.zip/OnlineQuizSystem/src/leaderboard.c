#include <stdio.h>
#include <string.h>
#include "user.h"

void viewLeaderboard() 
{
    FILE *file = fopen("data/users.dat", "rb");
    User users[100], temp;
    int count = 0;

    while (fread(&users[count], sizeof(User), 1, file)) 
    {
        count++;
    }
    fclose(file);

    for (int i = 0; i < count - 1; i++) 
    {
        for (int j = i + 1; j < count; j++) 
        {
            if (users[i].scores[0] < users[j].scores[0]) 
            {
                temp = users[i];
                users[i] = users[j];
                users[j] = temp;
            }
        }
    }

    printf("\n--- Leaderboard ---\n");
    for (int i = 0; i < count; i++) 
    {
        printf("%d. %s - %d\n", i + 1, users[i].username, users[i].scores[0]);
    }
}

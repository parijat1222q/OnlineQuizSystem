#include <stdio.h>
#include "user.h"
#include "quiz.h"
#include "admin.h"
#include "leaderboard.h"

int main() 
{
    User user;
    int choice, loggedIn = 0;

    do 
    {
        printf("\n--- Online Quiz System ---\n");
        printf("1. Register\n");
        printf("2. Login\n");
        printf("3. Attempt Quiz\n");
        printf("4. View Scores\n");
        printf("5. View Leaderboard\n");
        printf("6. Admin Panel\n");
        printf("7. Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);

        switch (choice) 
        {
            case 1:
                registerUser();
                break;
            case 2:
                loggedIn = loginUser(&user);
                break;
            case 3:
                if (loggedIn) 
                {
                    attemptQuiz(&user);
                } 
                else 
                {
                    printf("Please login first.\n");
                }
                break;
            case 4:
                if (loggedIn) 
                {
                    viewScores(user);
                } 
                else 
                {
                    printf("Please login first.\n");
                }
                break;
            case 5:
                viewLeaderboard();
                break;
            case 6:
                adminPanel();
                break;
            case 7:
                printf("Exiting...\n");
                break;
            default:
                printf("Invalid choice!\n");
        }
    } 
    while (choice != 7);

    return 0;
}

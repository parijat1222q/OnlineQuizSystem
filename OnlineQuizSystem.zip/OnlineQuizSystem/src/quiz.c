#include <stdio.h>
#include <string.h>
#include "quiz.h"
#include "user.h"

void attemptQuiz(User *user) 
{
    FILE *file = fopen("data/questions.dat", "rb");
    Question q;
    char answer;
    int score = 0;

    while (fread(&q, sizeof(Question), 1, file)) 
    {
        printf("\n%s", q.question);
        printf("A) %s", q.options[0]);
        printf("B) %s", q.options[1]);
        printf("C) %s", q.options[2]);
        printf("D) %s", q.options[3]);
        printf("\nYour answer: ");
        scanf(" %c", &answer);

        if (answer == q.correctOption) 
        {
            score++;
        }
    }
    fclose(file);

    for (int i = 0; i < 10; i++) 
    {
        if (user->scores[i] == 0) 
        {
            user->scores[i] = score;
            break;
        }
    }

    // Update user data
    file = fopen("data/users.dat", "rb+");
    User temp;
    while (fread(&temp, sizeof(User), 1, file)) 
    {
        if (strcmp(temp.username, user->username) == 0) 
        {
            fseek(file, -sizeof(User), SEEK_CUR);
            fwrite(user, sizeof(User), 1, file);
            break;
        }
    }
    fclose(file);

    printf("Quiz completed! Your score is: %d\n", score);
}

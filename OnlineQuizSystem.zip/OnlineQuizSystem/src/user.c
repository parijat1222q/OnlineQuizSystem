#include <stdio.h>
#include <string.h>
#include "user.h"

void registerUser() 
{
    FILE *file = fopen("data/users.dat", "ab");
    User newUser;
    printf("Enter Username: ");
    scanf("%s", newUser.username);
    printf("Enter Password: ");
    scanf("%s", newUser.password);
    for (int i = 0; i < 10; i++) 
    {
        newUser.scores[i] = 0;
    }
    fwrite(&newUser, sizeof(User), 1, file);
    fclose(file);
    printf("User registered successfully!\n");
}

int loginUser(User *user) 
{
    FILE *file = fopen("data/users.dat", "rb");
    User temp;
    char username[50], password[50];

    printf("Enter Username: ");
    scanf("%s", username);
    printf("Enter Password: ");
    scanf("%s", password);

    while (fread(&temp, sizeof(User), 1, file)) 
    {
        if (strcmp(username, temp.username) == 0 && strcmp(password, temp.password) == 0) 
        {
            *user = temp;
            fclose(file);
            printf("Login successful!\n");
            return 1;
        }
    }
    fclose(file);
    printf("Invalid username or password!\n");
    return 0;
}

void viewScores(User user) 
{
    printf("Your last scores: ");
    for (int i = 0; i < 10; i++) 
    {
        if (user.scores[i] > 0) 
        {
            printf("%d ", user.scores[i]);
        }
    }
    printf("\n");
}
